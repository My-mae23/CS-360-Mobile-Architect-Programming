package com.example.myra_projecttwo;
// Model Class
public class Event {
    private String title;
    private String date;
    private String time;
    private String description;

    public Event(String title) {
        this.title = title;
        this.date = date;
        this.time = time;
        this.description = description;
    }

    public String getTitle() { return title; }
    public String getDate() { return date; }
    public String getTime() { return time; }
    public String getDescription() { return description; }
}
