# Myra Event Planner — Project Three Enhancement Notes

## Implemented
- Sign-in screen with required-field validation and incorrect-credential feedback.
- Account creation with username uniqueness and a minimum six-character password rule.
- Event model with title, date, time, location, category, and description.
- Create, edit, and confirm-before-delete event actions.
- Search across event title, location, and description; filter by category.
- Local persistence of account demo data and each user's events using SharedPreferences.
- Consistent programmatically built screen styling and empty-state messages.
- Removed the unused SMS permission request.

## How to use
1. Open the `MyraProjectTwo` folder in Android Studio and allow Gradle sync to complete.
2. Run the app on an emulator or Android device.
3. Select **Create Account**, choose a username and a password of at least six characters, and then sign in.
4. Use **+ Add event** to add event details. Title, date, and time are required.
5. Use each event's **Edit** and **Delete** controls. Search and category filter narrow the displayed list.
6. **Sign out** returns to the login screen.

## Architecture
- `Event.java`: event data model and JSON conversion used for local persistence.
- `EventAdapter.java`: retained RecyclerView adapter from the starter project.
- `MainActivity.java`: screen flow, input validation, event operations, search/filter, and persistence.
- Existing XML layout files and Android resources remain in the project as original coursework assets; the enhanced activity builds its updated views in Java.

## Important limitations
This is a local coursework prototype, not a production authentication system. Credentials are stored as plain text in device-local SharedPreferences. Do not use real credentials. A production app should use a secure authentication provider or backend, hashed credentials, authorization, and a database with suitable access controls. Events are stored on the device and do not synchronize across devices. Date and time are currently validated as non-empty text rather than parsed calendar values.

## Suggested verification checklist
- [ ] Empty username/password produces field errors.
- [ ] Incorrect credentials show a message and do not sign in.
- [ ] Duplicate usernames are rejected.
- [ ] A valid account can sign in and sign out.
- [ ] An event cannot be saved without title, date, and time.
- [ ] Create, edit, and delete update the visible list.
- [ ] Search matches title, location, and description.
- [ ] Category filtering works and can be reset to All categories.
- [ ] Events remain after closing and reopening the app on the same device.
- [ ] Test layout behavior on more than one screen size.
