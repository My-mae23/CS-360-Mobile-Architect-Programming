package com.example.myra_projecttwo;

import org.json.JSONException;
import org.json.JSONObject;

/** Data model for one user-managed event. */
public class Event {
    private String title, date, time, location, category, description;

    public Event(String title) { this(title, "", "", "", "Other", ""); }

    public Event(String title, String date, String time, String location, String category, String description) {
        this.title = clean(title); this.date = clean(date); this.time = clean(time);
        this.location = clean(location); this.category = clean(category); this.description = clean(description);
    }
    private static String clean(String value) { return value == null ? "" : value.trim(); }
    public String getTitle(){return title;} public String getDate(){return date;} public String getTime(){return time;}
    public String getLocation(){return location;} public String getCategory(){return category;} public String getDescription(){return description;}
    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject(); o.put("title",title); o.put("date",date); o.put("time",time);
        o.put("location",location); o.put("category",category); o.put("description",description); return o;
    }
    public static Event fromJson(JSONObject o) {
        return new Event(o.optString("title"),o.optString("date"),o.optString("time"),o.optString("location"),o.optString("category"),o.optString("description"));
    }
}
