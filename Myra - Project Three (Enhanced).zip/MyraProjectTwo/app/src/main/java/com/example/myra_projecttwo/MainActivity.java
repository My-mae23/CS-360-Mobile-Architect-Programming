package com.example.myra_projecttwo;

import android.app.AlertDialog;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Event planner demo. Local SharedPreferences storage is for coursework demonstration only. */
public class MainActivity extends AppCompatActivity {
    private final List<Event> events = new ArrayList<>();
    private SharedPreferences prefs;
    private String activeUser = "";
    private LinearLayout root, eventList;
    private EditText searchBox;
    private Spinner categoryFilter;
    private final int ink = 0xFF18324B, blue = 0xFF176B87, pale = 0xFFF2F7FA;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state); prefs = getSharedPreferences("event_planner", MODE_PRIVATE); showLogin();
    }
    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(ink);
        if (bold) t.setTypeface(null, Typeface.BOLD); t.setPadding(4,8,4,8); return t;
    }
    private EditText field(String hint, int type) {
        EditText e = new EditText(this); e.setSingleLine(type != InputType.TYPE_CLASS_TEXT + InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        e.setHint(hint); e.setInputType(type); e.setTextSize(16); e.setPadding(18,10,18,10); return e;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setOnClickListener(v -> action.run()); return b;
    }
    private void base(String heading) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(22,18,22,18); root.setBackgroundColor(pale);
        TextView title = text(heading,26,true); title.setTextColor(blue); root.addView(title); setContentView(root);
    }
    private void showLogin() {
        base("My Event Planner"); root.addView(text("Sign in to organize your events",16,false));
        EditText user = field("Username",InputType.TYPE_CLASS_TEXT);
        EditText pass = field("Password",InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        root.addView(user); root.addView(pass);
        root.addView(button("Sign In",() -> {
            String u=user.getText().toString().trim(), p=pass.getText().toString();
            if (u.isEmpty() || p.isEmpty()) { user.setError(u.isEmpty()?"Enter a username":null); pass.setError(p.isEmpty()?"Enter a password":null); return; }
            String saved=prefs.getString("user_"+u,null);
            if (saved == null || !saved.equals(p)) { Toast.makeText(this,"Incorrect username or password.",Toast.LENGTH_LONG).show(); return; }
            activeUser=u; loadEvents(); showEvents();
        }));
        root.addView(button("Create Account",() -> createAccount(user.getText().toString().trim(),pass.getText().toString())));
        root.addView(text("Coursework demo: account details and events are stored locally on this device. Do not use a real password.",13,false));
    }
    private void createAccount(String username, String password) {
        EditText u=field("Choose a username",InputType.TYPE_CLASS_TEXT), p=field("Choose a password (at least 6 characters)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        LinearLayout box=new LinearLayout(this); box.setPadding(12,4,12,4); box.setOrientation(LinearLayout.VERTICAL); box.addView(u); box.addView(p);
        new AlertDialog.Builder(this).setTitle("Create account").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Create",(d,w)->{
            String name=u.getText().toString().trim(), secret=p.getText().toString();
            if(name.isEmpty() || secret.length()<6) { Toast.makeText(this,"Enter a username and a password of at least 6 characters.",Toast.LENGTH_LONG).show(); return; }
            if(prefs.contains("user_"+name)){Toast.makeText(this,"That username already exists.",Toast.LENGTH_LONG).show();return;}
            // Plain-text local credentials are intentionally limited to this non-production teaching example.
            prefs.edit().putString("user_"+name,secret).apply(); Toast.makeText(this,"Account created. Sign in to continue.",Toast.LENGTH_LONG).show();
        }).show();
    }
    private void loadEvents() {
        events.clear(); JSONArray a;
        try { a=new JSONArray(prefs.getString("events_"+activeUser,"[]")); for(int i=0;i<a.length();i++) events.add(Event.fromJson(a.getJSONObject(i))); }
        catch(JSONException ignored) { Toast.makeText(this,"Saved events could not be read.",Toast.LENGTH_SHORT).show(); }
    }
    private void saveEvents() {
        JSONArray a=new JSONArray(); try { for(Event e:events) a.put(e.toJson()); } catch(JSONException ignored) { }
        prefs.edit().putString("events_"+activeUser,a.toString()).apply();
    }
    private void showEvents() {
        base("Hello, "+activeUser);
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.addView(button("+ Add event",this::eventDialog),new LinearLayout.LayoutParams(0,-2,1));
        actions.addView(button("Sign out",()->{activeUser="";showLogin();}),new LinearLayout.LayoutParams(0,-2,1)); root.addView(actions);
        searchBox=field("Search title, location, or description",InputType.TYPE_CLASS_TEXT); root.addView(searchBox);
        categoryFilter=new Spinner(this); String[] categories={"All categories","Personal","Work","Family","Community","Other"};
        categoryFilter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,categories)); root.addView(categoryFilter);
        ScrollView scroll=new ScrollView(this); eventList=new LinearLayout(this); eventList.setOrientation(LinearLayout.VERTICAL); scroll.addView(eventList);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        searchBox.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){renderEvents();} public void afterTextChanged(android.text.Editable e){}});
        categoryFilter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){renderEvents();}});
        renderEvents();
    }
    private void renderEvents() {
        if(eventList==null)return; eventList.removeAllViews(); String q=searchBox.getText().toString().toLowerCase(Locale.ROOT);
        String category=categoryFilter.getSelectedItem()==null?"All categories":categoryFilter.getSelectedItem().toString(); int shown=0;
        for(int i=0;i<events.size();i++) { final int index=i; Event e=events.get(i);
            String searchable=(e.getTitle()+" "+e.getLocation()+" "+e.getDescription()).toLowerCase(Locale.ROOT);
            if(!searchable.contains(q) || (!category.equals("All categories")&&!e.getCategory().equals(category)))continue;
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(14,10,14,10); card.setBackgroundColor(0xFFFFFFFF);
            TextView heading=text(e.getTitle(),20,true); card.addView(heading);
            card.addView(text(e.getDate()+"  •  "+e.getTime(),15,false)); card.addView(text("Location: "+(e.getLocation().isEmpty()?"Not specified":e.getLocation()),15,false));
            card.addView(text("Category: "+e.getCategory(),14,false)); card.addView(text(e.getDescription(),15,false));
            LinearLayout controls=new LinearLayout(this); controls.addView(button("Edit",()->eventDialog(index)),new LinearLayout.LayoutParams(0,-2,1));
            controls.addView(button("Delete",()->new AlertDialog.Builder(this).setTitle("Delete event?").setMessage("Delete ‘"+e.getTitle()+"’?").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{events.remove(index);saveEvents();renderEvents();}).show()),new LinearLayout.LayoutParams(0,-2,1));
            card.addView(controls); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,8,0,8); eventList.addView(card,lp); shown++;
        }
        if(shown==0) eventList.addView(text(events.isEmpty()?"No events yet. Select + Add event to get started.":"No events match your search and filter.",16,false));
    }
    private void eventDialog(){eventDialog(-1);}
    private void eventDialog(int editIndex) {
        Event old=editIndex>=0?events.get(editIndex):null;
        LinearLayout form=new LinearLayout(this); form.setPadding(16,0,16,0); form.setOrientation(LinearLayout.VERTICAL);
        ScrollView sc=new ScrollView(this); sc.addView(form);
        EditText title=field("Event name (required)",InputType.TYPE_CLASS_TEXT), date=field("Date (e.g., 2026-10-05)",InputType.TYPE_CLASS_TEXT), time=field("Time (e.g., 2:30 PM)",InputType.TYPE_CLASS_TEXT), location=field("Location",InputType.TYPE_CLASS_TEXT), desc=field("Description",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        desc.setSingleLine(false); desc.setMinLines(3);
        form.addView(title); form.addView(date); form.addView(time); form.addView(location);
        Spinner category=new Spinner(this); String[] cats={"Personal","Work","Family","Community","Other"}; category.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cats)); form.addView(text("Category",14,true)); form.addView(category); form.addView(desc);
        if(old!=null){title.setText(old.getTitle());date.setText(old.getDate());time.setText(old.getTime());location.setText(old.getLocation());desc.setText(old.getDescription());for(int i=0;i<cats.length;i++)if(cats[i].equals(old.getCategory()))category.setSelection(i);}
        new AlertDialog.Builder(this).setTitle(old==null?"Create event":"Edit event").setView(sc).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
            String name=title.getText().toString().trim(), dt=date.getText().toString().trim(), tm=time.getText().toString().trim();
            if(name.isEmpty()||dt.isEmpty()||tm.isEmpty()){Toast.makeText(this,"Event name, date, and time are required.",Toast.LENGTH_LONG).show();return;}
            Event updated=new Event(name,dt,tm,location.getText().toString(),category.getSelectedItem().toString(),desc.getText().toString());
            if(old==null)events.add(updated);else events.set(editIndex,updated); saveEvents();renderEvents();Toast.makeText(this,"Event saved.",Toast.LENGTH_SHORT).show();
        }).show();
    }
}
